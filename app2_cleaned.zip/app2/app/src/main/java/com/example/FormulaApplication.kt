package com.example

import android.app.Application
import com.example.data.local.AppDatabase
import com.example.data.local.ProgressManager
import com.example.data.local.SettingsManager
import com.example.repository.FormulaRepository

class FormulaApplication : Application() {
    val database by lazy { AppDatabase.getDatabase(this) }
    val repository by lazy { FormulaRepository(database.formulaDao()) }
    val settingsManager by lazy { SettingsManager(this) }
    val progressManager by lazy { ProgressManager(this) }
}
