package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val PureBlack = Color(0xFF000000)
val PureWhite = Color(0xFFFFFFFF)
val SurfaceDark = Color(0xFF121212)
val SurfaceVariantDark = Color(0xFF1E1E1E)
val SurfaceLightBorder = Color(0xFF2A2A2A)

val AccentPrimary = Color(0xFF6366F1) // Electric Indigo
val AccentSecondary = Color(0xFF14B8A6) // Neon Teal
val AccentWarning = Color(0xFFF59E0B) // Amber
val AccentError = Color(0xFFEF4444) // Red

val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFFA0A0A0)
val TextMuted = Color(0xFF6B7280)
