package com.example.ui.search

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.Formula
import com.example.repository.FormulaRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class SearchViewModel(private val repository: FormulaRepository) : ViewModel() {
    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query

    private val _results = MutableStateFlow<List<Formula>>(emptyList())
    val results: StateFlow<List<Formula>> = _results

    private var allFormulas: List<Formula> = emptyList()

    init {
        viewModelScope.launch {
            repository.getAllFormulas().collectLatest { formulas ->
                allFormulas = formulas
                updateResults(_query.value)
            }
        }
    }

    fun setQuery(newQuery: String) {
        _query.value = newQuery
        updateResults(newQuery)
    }

    private fun updateResults(q: String) {
        if (q.isBlank()) {
            _results.value = emptyList()
            return
        }
        val lowerQ = q.lowercase()
        _results.value = allFormulas.filter {
            it.title.lowercase().contains(lowerQ) ||
            it.topic.lowercase().contains(lowerQ) ||
            it.formulaText.lowercase().contains(lowerQ) ||
            it.explanation.lowercase().contains(lowerQ)
        }
    }
}

class SearchViewModelFactory(private val repository: FormulaRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(SearchViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return SearchViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
