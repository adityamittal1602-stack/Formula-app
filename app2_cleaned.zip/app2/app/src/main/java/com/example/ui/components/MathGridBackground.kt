package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Composable
fun MathGridBackground(
    modifier: Modifier = Modifier,
    gridColor: Color = Color.White.copy(alpha = 0.03f),
    gridSize: Dp = 40.dp
) {
    Canvas(modifier = modifier.fillMaxSize()) {
        val sizePx = gridSize.toPx()
        val width = size.width
        val height = size.height

        var x = 0f
        while (x < width) {
            drawLine(
                color = gridColor,
                start = Offset(x, 0f),
                end = Offset(x, height),
                strokeWidth = 1f
            )
            x += sizePx
        }

        var y = 0f
        while (y < height) {
            drawLine(
                color = gridColor,
                start = Offset(0f, y),
                end = Offset(width, y),
                strokeWidth = 1f
            )
            y += sizePx
        }
        
        // Add a radial gradient to fade the edges out into pure background
        drawRect(
            brush = Brush.radialGradient(
                colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.8f), Color.Black),
                center = Offset(width / 2, height / 3),
                radius = width * 0.8f
            ),
            size = size
        )
    }
}
