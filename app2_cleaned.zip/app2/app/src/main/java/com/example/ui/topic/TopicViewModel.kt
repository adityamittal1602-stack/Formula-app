package com.example.ui.topic

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.Formula
import com.example.repository.FormulaRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class TopicViewModel(
    private val repository: FormulaRepository,
    private val topicName: String
) : ViewModel() {

    private val _formulas = MutableStateFlow<List<Formula>>(emptyList())
    val formulas: StateFlow<List<Formula>> = _formulas.asStateFlow()

    init {
        viewModelScope.launch {
            repository.getFormulasByTopic(topicName).collect {
                _formulas.value = it
            }
        }
    }
}

class TopicViewModelFactory(
    private val repository: FormulaRepository,
    private val topicName: String
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(TopicViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return TopicViewModel(repository, topicName) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
