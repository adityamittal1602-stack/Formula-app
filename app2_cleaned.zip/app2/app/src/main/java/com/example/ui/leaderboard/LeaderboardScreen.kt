package com.example.ui.leaderboard

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.WorkspacePremium
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.components.bounceClick

@Composable
fun LeaderboardScreen(onBackClick: () -> Unit) {
    val context = LocalContext.current
    val application = context.applicationContext as com.example.FormulaApplication
    val progressManager = application.progressManager
    
    val userName by progressManager.userName.collectAsState()
    val xp by progressManager.xp.collectAsState()

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surface)
                        .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha=0.5f), CircleShape)
                        .bounceClick(onClick = onBackClick),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                        contentDescription = "Back",
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                }
                Spacer(modifier = Modifier.width(16.dp))
                Text(
                    text = "Leaderboard",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onBackground
                )
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            val ranks = listOf(
                Pair("$userName (You)", "$xp XP"),
                Pair("Sarah J.", "110 XP"),
                Pair("MathWiz99", "95 XP"),
                Pair("Emma C.", "80 XP"),
                Pair("Alex D.", "60 XP")
            ).sortedByDescending { it.second.replace(" XP", "").toIntOrNull() ?: 0 }

            items(ranks.size) { i ->
                val (name, score) = ranks[i]
                RankItem(rank = i + 1, name = name, xp = score, isCurrentUser = name.contains("(You)"))
            }
        }
    }
}

@Composable
fun RankItem(rank: Int, name: String, xp: String, isCurrentUser: Boolean) {
    val color = if (isCurrentUser) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
    val onColor = if (isCurrentUser) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(color)
            .border(1.dp, if(isCurrentUser) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha=0.3f), RoundedCornerShape(16.dp))
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = "#$rank", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold), color = onColor.copy(alpha=0.6f))
        Spacer(modifier = Modifier.width(16.dp))
        if (rank <= 3) {
            Icon(Icons.Rounded.WorkspacePremium, contentDescription = null, tint = Color(0xFFFFD700))
            Spacer(modifier = Modifier.width(8.dp))
        }
        Text(text = name, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = onColor, modifier = Modifier.weight(1f))
        Text(text = xp, style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold), color = onColor)
    }
}
