package com.example.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.seed.DataSeeder
import com.example.repository.FormulaRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class HomeViewModel(private val repository: FormulaRepository) : ViewModel() {

    val topics: StateFlow<List<String>> = repository.getAllTopics()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    init {
        checkAndSeedDatabase()
    }

    private fun checkAndSeedDatabase() {
        viewModelScope.launch {
            if (repository.getFormulaCount() == 0) {
                repository.insertAll(DataSeeder.getInitialFormulas())
            }
        }
    }
}

class HomeViewModelFactory(private val repository: FormulaRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(HomeViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return HomeViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
