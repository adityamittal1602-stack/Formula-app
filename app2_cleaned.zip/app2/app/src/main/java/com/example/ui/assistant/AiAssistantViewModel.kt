package com.example.ui.assistant

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

data class ChatMessage(val text: String, val isUser: Boolean, val isError: Boolean = false)

class AiAssistantViewModel : ViewModel() {
    private val _messages = MutableStateFlow<List<ChatMessage>>(
        listOf(ChatMessage("Hey Aditya! I'm your study buddy. Struggling with a formula? Let's crack it together! \uD83D\uDE80", isUser = false))
    )
    val messages: StateFlow<List<ChatMessage>> = _messages
    
    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    private val conversationHistory = mutableListOf<Content>()

    init {
        // System instruction can be prepended as history or we can use the systemInstruction field.
        // For Moshi simplicity, we'll just insert a dummy user message or just use standard prompt structure.
    }

    fun sendMessage(userText: String) {
        if (userText.isBlank()) return
        
        _messages.value = _messages.value + ChatMessage(userText, isUser = true)
        _isLoading.value = true
        
        conversationHistory.add(Content(listOf(Part(userText))))
        
        viewModelScope.launch {
            try {
                val apiKey = BuildConfig.GEMINI_API_KEY
                if (apiKey == "dummy_key" || apiKey.isEmpty()) {
                    _messages.value = _messages.value + ChatMessage(
                        "API key is missing! Please configure GEMINI_API_KEY in the Secrets Panel.", 
                        isUser = false, 
                        isError = true
                    )
                    _isLoading.value = false
                    return@launch
                }
                
                val sysPrompt = "You are a helpful, funny AI study companion for an app that teaches math and science formulas. You can chat, give hints without revealing answers, tell jokes, use clean memes, and motivate the user. Be concise, friendly, and feel like a real study buddy without becoming annoying."
                
                val request = GenerateContentRequest(
                    contents = conversationHistory,
                    systemInstruction = Content(listOf(Part(sysPrompt)))
                )
                
                val response = RetrofitClient.service.generateContent(apiKey, request)
                val replyText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text ?: "I'm not sure how to respond to that."
                
                conversationHistory.add(Content(listOf(Part(replyText))))
                _messages.value = _messages.value + ChatMessage(replyText, isUser = false)
            } catch (e: Exception) {
                _messages.value = _messages.value + ChatMessage("Error: ${e.message}", isUser = false, isError = true)
            } finally {
                _isLoading.value = false
            }
        }
    }
}
