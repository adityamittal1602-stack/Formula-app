package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.navigation.compose.rememberNavController
import com.example.ui.navigation.FormulaNavGraph
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.assistant.AiAssistantOrb

import androidx.compose.runtime.LaunchedEffect
import com.example.ui.assistant.AssistantEmotion
import com.example.ui.assistant.GlobalAssistantState

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            androidx.compose.foundation.layout.Box(modifier = Modifier.fillMaxSize()) {
                com.example.ui.components.MathGridBackground()
                val navController = rememberNavController()
                FormulaNavGraph(navController = navController)
                AiAssistantOrb()
                
                LaunchedEffect(Unit) {
                    kotlinx.coroutines.delay(1000)
                    GlobalAssistantState.triggerEvent(AssistantEmotion.CELEBRATING, "Welcome back! Ready to destroy some formulas?")
                }
            }
        }
      }
    }
  }
}
