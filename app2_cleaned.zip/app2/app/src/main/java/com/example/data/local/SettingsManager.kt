package com.example.data.local

import android.content.Context
import androidx.core.content.edit
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class SettingsManager(context: Context) {
    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    private val _isAiAssistantEnabled = MutableStateFlow(prefs.getBoolean("ai_assistant_enabled", true))
    val isAiAssistantEnabled: StateFlow<Boolean> = _isAiAssistantEnabled

    fun setAiAssistantEnabled(enabled: Boolean) {
        prefs.edit { putBoolean("ai_assistant_enabled", enabled) }
        _isAiAssistantEnabled.value = enabled
    }
}
