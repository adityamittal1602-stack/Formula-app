package com.example.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.example.ui.home.HomeScreen
import com.example.ui.topic.TopicScreen
import com.example.ui.formula.FormulaDetailScreen

object Routes {
    const val HOME = "home"
    const val SETTINGS = "settings"
    const val SEARCH = "search"
    const val PROFILE = "profile"
    const val LEADERBOARD = "leaderboard"
    const val FAVORITES = "favorites"
    const val TOPIC_LIST = "topic/{topicName}"
    const val FORMULA_DETAIL = "formula/{formulaId}"
    
    fun createTopicListRoute(topicName: String) = "topic/$topicName"
    fun createFormulaDetailRoute(formulaId: Int) = "formula/$formulaId"
}

@Composable
fun FormulaNavGraph(
    navController: NavHostController,
    modifier: Modifier = Modifier
) {
    NavHost(
        navController = navController,
        startDestination = Routes.HOME,
        modifier = modifier
    ) {
        composable(Routes.HOME) {
            HomeScreen(
                onTopicClick = { topicName ->
                    navController.navigate(Routes.createTopicListRoute(topicName))
                },
                onSettingsClick = {
                    navController.navigate(Routes.SETTINGS)
                },
                onSearchClick = {
                    navController.navigate(Routes.SEARCH)
                },
                onProfileClick = {
                    navController.navigate(Routes.PROFILE)
                },
                onLeaderboardClick = {
                    navController.navigate(Routes.LEADERBOARD)
                }
            )
        }
        
        composable(Routes.SETTINGS) {
            com.example.ui.settings.SettingsScreen(
                onBackClick = { navController.popBackStack() }
            )
        }
        
        composable(Routes.PROFILE) {
            com.example.ui.profile.ProfileScreen(
                onBackClick = { navController.popBackStack() }
            )
        }

        composable(Routes.LEADERBOARD) {
            com.example.ui.leaderboard.LeaderboardScreen(
                onBackClick = { navController.popBackStack() }
            )
        }

        composable(Routes.FAVORITES) {
            com.example.ui.favorites.FavoritesScreen(
                onBackClick = { navController.popBackStack() },
                onFormulaClick = { formulaId ->
                    navController.navigate(Routes.createFormulaDetailRoute(formulaId))
                }
            )
        }
        
        composable(Routes.SEARCH) {
            com.example.ui.search.SearchScreen(
                onBackClick = { navController.popBackStack() },
                onFormulaClick = { formulaId ->
                    navController.navigate(Routes.createFormulaDetailRoute(formulaId))
                }
            )
        }
        
        composable(
            route = Routes.TOPIC_LIST,
            arguments = listOf(navArgument("topicName") { type = NavType.StringType })
        ) { backStackEntry ->
            val topicName = backStackEntry.arguments?.getString("topicName") ?: ""
            TopicScreen(
                topicName = topicName,
                onBackClick = { navController.popBackStack() },
                onFormulaClick = { formulaId ->
                    navController.navigate(Routes.createFormulaDetailRoute(formulaId))
                }
            )
        }

        composable(
            route = Routes.FORMULA_DETAIL,
            arguments = listOf(navArgument("formulaId") { type = NavType.IntType })
        ) { backStackEntry ->
            val formulaId = backStackEntry.arguments?.getInt("formulaId") ?: return@composable
            FormulaDetailScreen(
                formulaId = formulaId,
                onBackClick = { navController.popBackStack() }
            )
        }
    }
}
