package com.example.ui.assistant

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.FormulaApplication
import com.example.ui.components.bounceClick
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

@Composable
fun AiAssistantOrb() {
    val context = LocalContext.current
    val application = context.applicationContext as FormulaApplication
    val isEnabled by application.settingsManager.isAiAssistantEnabled.collectAsState()
    
    if (!isEnabled) return

    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }
    var showChat by remember { mutableStateOf(false) }

    var currentEmotion by remember { mutableStateOf(AssistantEmotion.IDLE) }
    var speechMessage by remember { mutableStateOf<String?>(null) }
    
    val coroutineScope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        GlobalAssistantState.events.collect { event ->
            currentEmotion = event.emotion
            if (event.message != null) {
                speechMessage = event.message
            }
            coroutineScope.launch {
                delay(3000)
                if (currentEmotion == event.emotion) {
                    currentEmotion = AssistantEmotion.IDLE
                }
                if (speechMessage == event.message) {
                    speechMessage = null
                }
            }
        }
    }
    
    // Idle animations
    LaunchedEffect(currentEmotion) {
        if (currentEmotion == AssistantEmotion.IDLE) {
            while (true) {
                delay((3000..7000).random().toLong())
                if (currentEmotion == AssistantEmotion.IDLE) {
                    val idleAnim = listOf(AssistantEmotion.IDLE, AssistantEmotion.THINKING, AssistantEmotion.SURPRISED).random()
                    currentEmotion = idleAnim
                    delay(1000)
                    currentEmotion = AssistantEmotion.IDLE
                }
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        contentAlignment = Alignment.BottomEnd
    ) {
        Box(
            modifier = Modifier
                .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        offsetX += dragAmount.x
                        offsetY += dragAmount.y
                    }
                }
        ) {
            Column(horizontalAlignment = Alignment.End) {
                AnimatedVisibility(
                    visible = speechMessage != null,
                    enter = scaleIn() + fadeIn(),
                    exit = scaleOut() + fadeOut()
                ) {
                    Box(
                        modifier = Modifier
                            .padding(bottom = 8.dp, end = 16.dp)
                            .clip(RoundedCornerShape(16.dp, 16.dp, 0.dp, 16.dp))
                            .background(MaterialTheme.colorScheme.surface)
                            .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha=0.5f), RoundedCornerShape(16.dp, 16.dp, 0.dp, 16.dp))
                            .padding(12.dp)
                    ) {
                        Text(
                            text = speechMessage ?: "",
                            color = MaterialTheme.colorScheme.onSurface,
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                }
                
                AnimatedFace(
                    emotion = currentEmotion,
                    modifier = Modifier
                        .size(64.dp)
                        .bounceClick { showChat = true }
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(Color(0xFF8B5CF6), Color(0xFFEC4899))))
                        .border(2.dp, Color.White.copy(alpha = 0.5f), CircleShape)
                )
            }
        }
    }
    
    if (showChat) {
        Dialog(onDismissRequest = { showChat = false }) {
            AiAssistantChatBox(onDismiss = { showChat = false })
        }
    }
}

@Composable
fun AnimatedFace(emotion: AssistantEmotion, modifier: Modifier = Modifier) {
    val infiniteTransition = rememberInfiniteTransition()
    val bounceOffset by infiniteTransition.animateFloat(
        initialValue = -5f,
        targetValue = 5f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ), label = "bounce"
    )

    val blinkState by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = keyframes {
                durationMillis = 4000
                1f at 3800
                0.1f at 3900
                1f at 4000
            }
        ), label = "blink"
    )

    androidx.compose.foundation.Canvas(modifier = modifier.offset(y = if (emotion == AssistantEmotion.IDLE) bounceOffset.dp else 0.dp)) {
        val center = Offset(size.width / 2, size.height / 2)
        val eyeRadius = size.width * 0.08f
        
        when (emotion) {
            AssistantEmotion.IDLE -> {
                // Normal eyes
                drawCircle(Color.White, radius = eyeRadius, center = center.copy(x = center.x - size.width * 0.2f, y = center.y * blinkState))
                drawCircle(Color.White, radius = eyeRadius, center = center.copy(x = center.x + size.width * 0.2f, y = center.y * blinkState))
                // Smile
                drawArc(
                    color = Color.White,
                    startAngle = 20f,
                    sweepAngle = 140f,
                    useCenter = false,
                    topLeft = Offset(center.x - size.width * 0.15f, center.y + size.height * 0.1f),
                    size = Size(size.width * 0.3f, size.height * 0.15f),
                    style = Stroke(width = 8f, cap = StrokeCap.Round)
                )
            }
            AssistantEmotion.THINKING -> {
                // Eyes looking up
                drawCircle(Color.White, radius = eyeRadius, center = center.copy(x = center.x - size.width * 0.2f, y = center.y - size.height * 0.1f))
                drawCircle(Color.White, radius = eyeRadius, center = center.copy(x = center.x + size.width * 0.2f, y = center.y - size.height * 0.1f))
                // Small mouth
                drawCircle(Color.White, radius = eyeRadius * 0.5f, center = center.copy(y = center.y + size.height * 0.15f))
            }
            AssistantEmotion.SLEEPING -> {
                // Closed eyes (lines)
                drawLine(Color.White, start = center.copy(x = center.x - size.width * 0.25f), end = center.copy(x = center.x - size.width * 0.15f), strokeWidth = 6f, cap = StrokeCap.Round)
                drawLine(Color.White, start = center.copy(x = center.x + size.width * 0.15f), end = center.copy(x = center.x + size.width * 0.25f), strokeWidth = 6f, cap = StrokeCap.Round)
                // Small mouth
                drawCircle(Color.White, radius = eyeRadius * 0.5f, center = center.copy(y = center.y + size.height * 0.1f))
            }
            AssistantEmotion.CELEBRATING -> {
                // Happy eyes (arches)
                drawArc(Color.White, 180f, 180f, false, topLeft = Offset(center.x - size.width * 0.25f, center.y - eyeRadius), size = Size(eyeRadius*2, eyeRadius*2), style = Stroke(width = 8f, cap = StrokeCap.Round))
                drawArc(Color.White, 180f, 180f, false, topLeft = Offset(center.x + size.width * 0.09f, center.y - eyeRadius), size = Size(eyeRadius*2, eyeRadius*2), style = Stroke(width = 8f, cap = StrokeCap.Round))
                // Big Smile
                drawArc(
                    color = Color.White,
                    startAngle = 0f,
                    sweepAngle = 180f,
                    useCenter = false,
                    topLeft = Offset(center.x - size.width * 0.2f, center.y + size.height * 0.05f),
                    size = Size(size.width * 0.4f, size.height * 0.2f),
                    style = Stroke(width = 8f, cap = StrokeCap.Round)
                )
            }
            AssistantEmotion.SURPRISED -> {
                // Wide eyes
                drawCircle(Color.White, radius = eyeRadius * 1.5f, center = center.copy(x = center.x - size.width * 0.2f))
                drawCircle(Color.White, radius = eyeRadius * 1.5f, center = center.copy(x = center.x + size.width * 0.2f))
                // Open mouth (O)
                drawCircle(Color.White, radius = eyeRadius * 1.2f, center = center.copy(y = center.y + size.height * 0.15f), style = Stroke(width = 8f))
            }
            AssistantEmotion.LAUGHING -> {
                // Happy eyes
                drawArc(Color.White, 180f, 180f, false, topLeft = Offset(center.x - size.width * 0.25f, center.y - eyeRadius), size = Size(eyeRadius*2, eyeRadius*2), style = Stroke(width = 8f, cap = StrokeCap.Round))
                drawArc(Color.White, 180f, 180f, false, topLeft = Offset(center.x + size.width * 0.09f, center.y - eyeRadius), size = Size(eyeRadius*2, eyeRadius*2), style = Stroke(width = 8f, cap = StrokeCap.Round))
                // Laughing mouth
                drawArc(
                    color = Color.White,
                    startAngle = 0f,
                    sweepAngle = 180f,
                    useCenter = true, // Filled
                    topLeft = Offset(center.x - size.width * 0.2f, center.y + size.height * 0.05f),
                    size = Size(size.width * 0.4f, size.height * 0.25f)
                )
            }
            AssistantEmotion.CONFUSED -> {
                // One eye big, one normal
                drawCircle(Color.White, radius = eyeRadius * 1.3f, center = center.copy(x = center.x - size.width * 0.2f))
                drawCircle(Color.White, radius = eyeRadius, center = center.copy(x = center.x + size.width * 0.2f))
                // Wavy/straight mouth
                drawLine(Color.White, start = center.copy(x = center.x - size.width * 0.15f, y = center.y + size.height * 0.15f), end = center.copy(x = center.x + size.width * 0.15f, y = center.y + size.height * 0.1f), strokeWidth = 8f, cap = StrokeCap.Round)
            }
            AssistantEmotion.FOCUSED -> {
                // Intense eyes
                drawArc(Color.White, 0f, -180f, false, topLeft = Offset(center.x - size.width * 0.25f, center.y - eyeRadius), size = Size(eyeRadius*2, eyeRadius*2), style = Stroke(width = 8f, cap = StrokeCap.Round))
                drawArc(Color.White, 0f, -180f, false, topLeft = Offset(center.x + size.width * 0.09f, center.y - eyeRadius), size = Size(eyeRadius*2, eyeRadius*2), style = Stroke(width = 8f, cap = StrokeCap.Round))
                // Straight mouth
                drawLine(Color.White, start = center.copy(x = center.x - size.width * 0.15f, y = center.y + size.height * 0.15f), end = center.copy(x = center.x + size.width * 0.15f, y = center.y + size.height * 0.15f), strokeWidth = 8f, cap = StrokeCap.Round)
            }
        }
    }
}
