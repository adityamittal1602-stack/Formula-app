package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "formulas")
data class Formula(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val topic: String,
    val title: String,
    val formulaText: String,
    val explanation: String,
    val visualExplanation: String,
    val easyIntuition: String,
    val pattern: String,
    val mnemonic: String,
    val funnyMemoryTrick: String,
    val story: String,
    val indianMemeVersion: String,
    val commonMistake: String,
    val example: String,
    val practiceQuestion: String,
    val reverseRecallQuestion: String,
    val difficulty: String,
    val masteryLevel: Int = 0,
    val isFavorite: Boolean = false,
    val lastViewedTimestamp: Long = 0L
)
