package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.Formula
import kotlinx.coroutines.flow.Flow

@Dao
interface FormulaDao {
    @Query("SELECT * FROM formulas WHERE topic = :topic")
    fun getFormulasByTopic(topic: String): Flow<List<Formula>>

    @Query("SELECT * FROM formulas WHERE id = :id")
    fun getFormulaById(id: Int): Flow<Formula>
    
    @Query("SELECT * FROM formulas")
    fun getAllFormulas(): Flow<List<Formula>>

    @Query("SELECT DISTINCT topic FROM formulas")
    fun getAllTopics(): Flow<List<String>>
    
    @Query("SELECT COUNT(*) FROM formulas")
    suspend fun getFormulaCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(formulas: List<Formula>)
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(formula: Formula)

    @Query("UPDATE formulas SET masteryLevel = :masteryLevel WHERE id = :id")
    suspend fun updateMasteryLevel(id: Int, masteryLevel: Int)
    
    @Query("UPDATE formulas SET isFavorite = :isFavorite WHERE id = :id")
    suspend fun updateFavoriteStatus(id: Int, isFavorite: Boolean)

    @Query("SELECT * FROM formulas WHERE isFavorite = 1")
    fun getFavoriteFormulas(): Flow<List<Formula>>
}
