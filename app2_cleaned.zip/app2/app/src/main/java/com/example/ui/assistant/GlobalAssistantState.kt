package com.example.ui.assistant

import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow

enum class AssistantEmotion {
    IDLE, THINKING, SLEEPING, CELEBRATING, LAUGHING, CONFUSED, SURPRISED, FOCUSED
}

data class AssistantEvent(
    val emotion: AssistantEmotion,
    val message: String? = null
)

object GlobalAssistantState {
    private val _events = MutableSharedFlow<AssistantEvent>(extraBufferCapacity = 10)
    val events = _events.asSharedFlow()

    fun triggerEvent(emotion: AssistantEmotion, message: String? = null) {
        _events.tryEmit(AssistantEvent(emotion, message))
    }
}
