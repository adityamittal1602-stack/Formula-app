package com.example.repository

import com.example.data.local.FormulaDao
import com.example.data.model.Formula
import kotlinx.coroutines.flow.Flow

class FormulaRepository(private val formulaDao: FormulaDao) {
    fun getFormulasByTopic(topic: String): Flow<List<Formula>> = formulaDao.getFormulasByTopic(topic)
    
    fun getFormulaById(id: Int): Flow<Formula> = formulaDao.getFormulaById(id)
    
    fun getAllFormulas(): Flow<List<Formula>> = formulaDao.getAllFormulas()
    
    fun getAllTopics(): Flow<List<String>> = formulaDao.getAllTopics()
    
    suspend fun getFormulaCount(): Int = formulaDao.getFormulaCount()
    
    suspend fun updateMasteryLevel(id: Int, masteryLevel: Int) {
        formulaDao.updateMasteryLevel(id, masteryLevel)
    }
    
    suspend fun toggleFavorite(id: Int, isFavorite: Boolean) {
        formulaDao.updateFavoriteStatus(id, isFavorite)
    }

    fun getFavoriteFormulas(): Flow<List<Formula>> = formulaDao.getFavoriteFormulas()
    
    suspend fun insertAll(formulas: List<Formula>) {
        formulaDao.insertAll(formulas)
    }
}
