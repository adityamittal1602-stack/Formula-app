package com.example.data.local

import android.content.Context
import androidx.core.content.edit
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class ProgressManager(context: Context) {
    private val prefs = context.getSharedPreferences("user_progress", Context.MODE_PRIVATE)

    private val _xp = MutableStateFlow(prefs.getInt("xp", 120))
    val xp: StateFlow<Int> = _xp

    private val _streak = MutableStateFlow(prefs.getInt("streak", 12))
    val streak: StateFlow<Int> = _streak

    private val _rank = MutableStateFlow(prefs.getString("rank", "Gold Tier II") ?: "Gold Tier II")
    val rank: StateFlow<String> = _rank
    
    private val _userName = MutableStateFlow(prefs.getString("user_name", "Aditya") ?: "Aditya")
    val userName: StateFlow<String> = _userName

    fun addXp(amount: Int) {
        val newXp = _xp.value + amount
        prefs.edit { putInt("xp", newXp) }
        _xp.value = newXp
        // Check for rank up here if needed
    }
}
