package com.example.ui.formula

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.Formula
import com.example.repository.FormulaRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class FormulaDetailViewModel(
    private val repository: FormulaRepository,
    private val formulaId: Int
) : ViewModel() {

    private val _formula = MutableStateFlow<Formula?>(null)
    val formula: StateFlow<Formula?> = _formula.asStateFlow()

    init {
        viewModelScope.launch {
            repository.getFormulaById(formulaId).collect {
                _formula.value = it
            }
        }
    }

    fun updateMasteryLevel(level: Int) {
        viewModelScope.launch {
            repository.updateMasteryLevel(formulaId, level)
        }
    }
    
    fun toggleFavorite() {
        viewModelScope.launch {
            _formula.value?.let { currentFormula ->
                repository.toggleFavorite(formulaId, !currentFormula.isFavorite)
            }
        }
    }
}

class FormulaDetailViewModelFactory(
    private val repository: FormulaRepository,
    private val formulaId: Int
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(FormulaDetailViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return FormulaDetailViewModel(repository, formulaId) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
